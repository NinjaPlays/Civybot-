import discord
from discord.ext import commands
import os
import random
import time
import json

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)

# Data storage
DATA_FILE = "players.json"

def load_data():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r") as f:
            return json.load(f)
    return {}

def save_data():
    with open(DATA_FILE, "w") as f:
        json.dump(players, f)

players = load_data()

# Announcements channel (replace with your own channel ID)
ANNOUNCE_CHANNEL_ID = 123456789012345678  

# Cooldowns
quickmine_cooldowns = {}
bigmine_cooldowns = {}
daily_cooldowns = {}

@bot.event
async def on_ready():
    print(f"✅ {bot.user} is online and ready!")

@bot.command()
async def resources(ctx):
    user = str(ctx.author.id)
    if user not in players:
        players[user] = {"gold": 0, "wood": 0, "stone": 0, "iron": 0}
    stats = players[user]
    await ctx.send(
        f"📦 Resources for {ctx.author.mention}:\n"
        f"💰 Gold: {stats['gold']}\n"
        f"🪵 Wood: {stats['wood']}\n"
        f"🪨 Stone: {stats['stone']}\n"
        f"⛓️ Iron: {stats['iron']}"
    )

@bot.command()
async def quickmine(ctx, resource: str):
    user = str(ctx.author.id)
    now = time.time()
    if user in quickmine_cooldowns and now - quickmine_cooldowns[user] < 30:
        await ctx.send("⏳ You must wait 30 seconds before mining again!")
        return
    quickmine_cooldowns[user] = now

    if user not in players:
        players[user] = {"gold": 0, "wood": 0, "stone": 0, "iron": 0}

    if resource not in ["wood", "stone", "iron"]:
        await ctx.send("❌ Invalid resource! Choose wood, stone, or iron.")
        return

    amount = random.randint(8, 12)
    players[user][resource] += amount
    save_data()
    await ctx.send(f"⛏️ {ctx.author.mention} mined {amount} {resource}!")

@bot.command()
async def bigmine(ctx, resource: str):
    user = str(ctx.author.id)
    now = time.time()
    if user in bigmine_cooldowns and now - bigmine_cooldowns[user] < 86400:
        await ctx.send("⏳ You can only use !bigmine once every 24 hours!")
        return
    bigmine_cooldowns[user] = now

    if user not in players:
        players[user] = {"gold": 0, "wood": 0, "stone": 0, "iron": 0}

    if resource not in ["wood", "stone", "iron"]:
        await ctx.send("❌ Invalid resource! Choose wood, stone, or iron.")
        return

    amount = random.randint(90, 120)
    players[user][resource] += amount
    save_data()
    await ctx.send(f"💥 {ctx.author.mention} performed a BIG MINE and got {amount} {resource}!")

@bot.command()
async def daily(ctx):
    user = str(ctx.author.id)
    now = time.time()
    if user in daily_cooldowns and now - daily_cooldowns[user] < 86400:
        await ctx.send("⏳ You can only claim daily resources once every 24 hours!")
        return
    daily_cooldowns[user] = now

    if user not in players:
        players[user] = {"gold": 0, "wood": 0, "stone": 0, "iron": 0}

    wood = random.randint(90, 120)
    stone = random.randint(90, 120)
    iron = random.randint(90, 120)

    players[user]["wood"] += wood
    players[user]["stone"] += stone
    players[user]["iron"] += iron
    save_data()

    channel = bot.get_channel(ANNOUNCE_CHANNEL_ID)
    if channel:
        await channel.send(
            f"📢 @everyone {ctx.author.mention} has claimed their daily resources!\n"
            f"🪵 {wood} Wood | 🪨 {stone} Stone | ⛓️ {iron} Iron"
        )
    else:
        await ctx.send("⚠️ Announcement channel not found!")

# Run bot with Heroku token
bot.run(os.getenv("BOT_TOKEN"))
